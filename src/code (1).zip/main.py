from Car import Car
from CarDrive import CarDrive
from Clothing import Clothing
from Food import Food
from Island import Island
from Story import Story
import time

c1 = Clothing()
f1 = Food()
cr1 = Car()
cd1 = CarDrive()
s1 = Story()
i1 = Island()

#s1.Part1()
#c1.choices()
#f1.FoodChoice()
#f1.LeaveHouse()
#c1.leaveHouse()
#cr1.GoToCar()
#cd1.Drive()
#s1.Part2()
i1.Arrive()


    