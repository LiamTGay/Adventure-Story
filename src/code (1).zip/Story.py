class Story:

  def Part1(self):
    print("Your boyfriend(solomander) recently got kidnapped by the evil wizard and brought to his evil lair(an island in the middle of the Carribean sea)")

  def Part2(self):
    print("Upon arriving at the island, you find Solomander waiting for you")
    print("You bring Solomander along on your quest to defeat the evil wizard")
  
  #def Part3(self):
  #def Part4(self):
  #def Part5(self):
  #def Part6(self):